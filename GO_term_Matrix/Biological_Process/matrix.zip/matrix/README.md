Script will take Input as Gene stable ID list.Input file should not contain any header and other column then gene stable id list
Input file should be saved as pathway name 
script requires combinatin list for both WGD and preWGD species and file.txt and file.prewgd.txt files
